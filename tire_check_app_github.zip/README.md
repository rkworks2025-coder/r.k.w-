# Tire Check App

iPhoneでも使えるタイヤ点検記録用チェックアプリ。
GitHub Pagesで公開して、Safariの「ホーム画面に追加」でアプリのように使えます。
